#include <Arduino.h>
#include <SPI.h>
#include <gamma.h>
#include <smileytongue24.h>
#include <Adafruit_GFX.h>
#include <Adafruit_I2CDevice.h>
#include <RGBmatrixPanelCustom.h>

#define CLK 11 
#define OE   9
#define LAT 10
#define A   A0
#define B   A1
#define C   A2
#define D   A3

RGBmatrixPanel matrix(A, B, C, D, CLK, LAT, OE, false, 64);


#define F2(progmem_ptr) (const __FlashStringHelper *)progmem_ptr

const char str[] PROGMEM = "Hallo";
int16_t    textX         = matrix.width(),
           textMin       = (int16_t)sizeof(str) * -12,
           hue           = 0;

void setup() {
  matrix.begin();
  matrix.setTextWrap(false);
  matrix.setTextSize(2);
  Serial.begin(9600);
  Serial.println("Done");
}

void loop() {
  matrix.drawLine(2,2,6,6,0x1111);

  matrix.swapBuffers(false);
}
